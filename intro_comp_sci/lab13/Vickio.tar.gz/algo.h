#ifndef algo_H
#define algo_H

void selectionSort(int numberArray[], int num);
void insertionSort(int numberArray[], int num);
void bubbleSort(int numberArray[], int num);
void quickSort(int low, int high, int numberArray[]);
void writeArrayToFile(int array[], int num);

#endif
