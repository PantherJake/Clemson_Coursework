#include <stdio.h>

// Jacob Vickio, jvickio, 2

int main() {
	int min = 0;
	int max = 10;
		
	for(int i = min; i <= max; i++) {
		printf("%d ", i);
	}

	printf("\n");
	return 0;
}
