#ifndef FUNCTIONS_H
#define FUNCTIONS_H

/**************************
 *Jacob Vickio
 *CPSC2310 Spring 2021            
 *UserName: jvickio                               
 *Instructor:  Dr. Yvon Feaster  
*************************/

int printReturn(int a, int b, int action);

#endif