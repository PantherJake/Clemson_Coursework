#include "functions.h"

/**************************
 *Jacob Vickio                                
 *CPSC2310 Lab7                         
 *UserName: jvickio                                
 *Lab Section: 002                               
/************************/

int main()
{
    printf("%d\n", isArithmetic());
    return 0;
}
