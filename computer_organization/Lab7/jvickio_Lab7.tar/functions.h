#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

/**************************
 *Jacob Vickio                                
 *CPSC2310 Lab7                         
 *UserName: jvickio                                
 *Lab Section: 002                               
/************************/

int isArithmetic();
int isOddOne(unsigned);

#endif