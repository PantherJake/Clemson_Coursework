#include<fstream>
#include"pixelArt.h"

void pixelArt::readArts(string fileName)
{
}

pixelArt::pixelArt(int iw, int ih):w(iw),h(ih)
{
}

int pixelArt::getPixel(int i, int j)
{
}

int pixelArt::getW()
{
}

int pixelArt::getH()
{
}


pixelArt pixelArt::operator + (int num)
{
}

pixelArt pixelArt::operator - (int num)
{
}

pixelArt pixelArt::operator + (const pixelArt& pa)
{
}

ostream& operator<<(ostream& os, const pixelArt& pa)
{
}
