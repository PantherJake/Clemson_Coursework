#include <iostream>
using namespace std;

int main() {
	cout << "This is my first C++ program!\n" << "I love Linux!\n";
	return 0;
}
